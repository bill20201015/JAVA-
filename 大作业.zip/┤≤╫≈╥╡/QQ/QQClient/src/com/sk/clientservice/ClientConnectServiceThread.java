package com.sk.clientservice;

import com.sk.qqcommon.Message;
import com.sk.qqcommon.MessageType;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

/**
 * @author sk
 * @version 1.0
 */
public class ClientConnectServiceThread extends Thread{
    //必须持有Socket
    private Socket socket;
    public ClientConnectServiceThread(Socket socket){
        this.socket = socket;
    }
    @Override
    public void run(){
        while(true){

            try {
                System.out.println("我们的客户端线程等待读取从读取服务端发送消息");
                ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
                Message me = (Message) ois.readObject();
                //判断这个message的类型，然后做相应的业务处理
                //如果读取到的是服务端返回的是在线用户列表
                if(me.getMesType().equals(MessageType.MESSAGE_GET_ONLINE_FRIEND)){
                    String[] onlineUsers = me.getContent().split(" ");
                    System.out.println("\n-----当前在线用户对象列表----");
                    for (int i = 0; i < onlineUsers.length; i++) {
                        System.out.println("用户:"+onlineUsers[i]);
                    }
                }else if(me.getMesType().equals(MessageType.MESSAGE_COMM_MES)){
                    System.out.println("\n" + me.getSender()+
                            "对"+me.getGetter() + "说"+ me.getContent());
                }else if(me.getMesType().equals(MessageType.MESSAGE_TO_ALL_MES)){
                    System.out.println("\n"+me.getSender()+"对大家说"+me.getContent());
                }
                else{
                    System.out.println("暂不处理其余选择");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    public Socket getSocket(){
        return socket;
    }
}
