package com.sk.clientservice;

import java.util.HashMap;

/**
 * @author sk
 * @version 1.0
 * 该类管理客户端连接到服务器的线程的类
 */
public class ManageClientConnectServerThread {
    //我们把多个线程放入到HashMap集合中，key是id，value是线程
    private  static HashMap<String, ClientConnectServiceThread> hm = new HashMap<>();
    //将某个线程加入到集合
    public static void addClientConnectServerThread(String userID, ClientConnectServiceThread clientConnectServiceThread){
        hm.put(userID, clientConnectServiceThread);
    }
    //通过userID，可以得到对应的线程
    public static ClientConnectServiceThread getClientConnectServiceThread(String userID){
        return hm.get(userID);
    }
}
