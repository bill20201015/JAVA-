package com.sk.clientservice;

import com.sk.qqcommon.Message;
import com.sk.qqcommon.MessageType;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Date;

/**
 * @author sk
 * @version 1.0
 * 该对象提供和消息相关的服务方法
 */
public class MessageClientService {

    public void sendMessageToOne(String content, String senderID, String getterID){
        //构建messge
        Message message = new Message();
        message.setSender(senderID);
        message.setMesType(MessageType.MESSAGE_COMM_MES);
        message.setGetter(getterID);
        message.setContent(content);
        message.setSendTime(new Date().toString());//发送时间
        System.out.println(senderID + "对" + getterID + "说"+ content);
        try {
            ObjectOutputStream oos = new
                    ObjectOutputStream(ManageClientConnectServerThread.getClientConnectServiceThread(senderID).getSocket().getOutputStream());
            oos.writeObject(message);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    /**
     *
     * @param content
     * @param senderID
     */
    //群发消息
    public void sendMessageToAll(String content, String senderID){
        //构建messge
        Message message = new Message();
        message.setSender(senderID);
        message.setMesType(MessageType.MESSAGE_TO_ALL_MES);

        message.setContent(content);
        message.setSendTime(new Date().toString());//发送时间
        System.out.println(senderID + "对大家说"+ content);
        try {
            ObjectOutputStream oos = new
                    ObjectOutputStream(ManageClientConnectServerThread.getClientConnectServiceThread(senderID).getSocket().getOutputStream());
            oos.writeObject(message);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
