package com.sk.clientservice;

import com.sk.qqcommon.Message;
import com.sk.qqcommon.MessageType;
import com.sk.qqcommon.User;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

/**
 * @author sk
 * @version 1.0
 * 该类完成用户登录验证等等功能
 */
public class UserClientService {
    //其它地方可能也要用到user信息，所以就将其作为成员属性
    private User user = new User();
    //socket也一样作为成员属性
    private Socket socket;
    public boolean checkUser(String uid, String password){
        boolean b = false;
        //创建一个user对象
        user.setUserID(uid);
        user.setPassword(password);
        //连接服务器，发送user对象
        try {
            socket = new Socket(InetAddress.getByName("127.0.0.1"), 9999);
            ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
            oos.writeObject(user);
            //读取从服务端回复的Message信息
            ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
            Message ms = (Message) ois.readObject();//如果服务器没有发送message对象，线程会阻塞在这

            if(ms.getMesType().equals(MessageType.MESSAGE_LOGIN_SUCCEED)){
                //登陆成功，创建一个和服务器端保持通信的一个线程
                //ClientConnectServiceThread
                ClientConnectServiceThread clientConnectServiceThread = new ClientConnectServiceThread(socket);
                clientConnectServiceThread.start();
                //为了客户端的扩展，我们将线程放入到集合
                ManageClientConnectServerThread.addClientConnectServerThread(uid,clientConnectServiceThread);
                b = true;
            }else{
                //登录失败,就没有启用相应的线程，不能启动服务器
                //需要管壁socket
                socket.close();

            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return b;
    }

    //向服务器端请求在线用户列表
    public void onlineFriendList(){

        //发送一个Message，类型为MESSag_GET_O
        Message message = new Message();
        message.setMesType(MessageType.MESSAGE_GET_ONLINE_FRIEND);
        message.setSender(user.getUserID());
        //发送给服务器
        try {
            //应当得到当前线程的Socket对应的 ObjectOutputStream对象
            ObjectOutputStream oos = new ObjectOutputStream
                    (ManageClientConnectServerThread.getClientConnectServiceThread(user.getUserID()).getSocket().getOutputStream());
            oos.writeObject(message);//发送一个message对象，向服务器获取在线用户对象
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //编写方法,退出客户端，并给服务端发送一个退出系统的message对象
    public void logout(){
        //发送一个Message对象
        Message message = new Message();
        message.setMesType(MessageType.MESSAGE_CLINT_EXIT);
        message.setSender(user.getUserID());//一定要指明是那个客户端，服务端要根据ID名字关闭相应线程

        try {
            ObjectOutputStream oos  = new ObjectOutputStream
                    (ManageClientConnectServerThread.getClientConnectServiceThread(user.getUserID()).getSocket().getOutputStream());
            oos.writeObject(message);
            System.out.println(user.getUserID() + "退出系统");
            System.exit(0);//结束进程
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
