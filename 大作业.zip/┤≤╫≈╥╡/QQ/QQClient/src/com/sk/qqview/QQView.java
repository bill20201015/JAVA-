package com.sk.qqview;
import com.sk.clientservice.MessageClientService;
import com.sk.clientservice.UserClientService;
import com.sk.qqview.utils.Utility;

/**
 * @author sk
 * @version 1.0
 * 菜单界面
 */
public class QQView {

    private boolean loop = true;//控制菜单是否显示
    private String key = ""; //读取输入控制
    private UserClientService userClientService = new UserClientService();//用于登录服务器/注册
    private MessageClientService messageClientService = new MessageClientService();//用于消息的发送

    public static void main(String[] args) {
        QQView qqView = new QQView();
        qqView.mainView();
    }

    //显示主菜单
    private void mainView(){
        while(loop){
            System.out.println("-----------欢迎登录山寨版QQ通信系统------------");
            System.out.println("\t\t1 登入系统");
            System.out.println("\t\t9 退出登录");
            System.out.println("请输入你的选择");
            key = Utility.readString(1);
            //根据用户输入，处理不同的逻辑
            switch (key){
                case "1":
                    System.out.println("请输入用户名:");
                    String userID = Utility.readString(50);
                    System.out.println("请输入密 码:");
                    String password = Utility.readString(50);
                    //这里需要去服务端，去验证用户名密码是否正确
                    //编写一个类userClientService
                    if(userClientService.checkUser(userID, password)){
                        System.out.println("-----------欢迎"+userID+"登录山寨版QQ------------");
                        while(loop){
                            System.out.println("-----------山寨版QQ通信系统二级菜单------------");
                            System.out.println("\t\t1 拉取在线用户列表");
                            System.out.println("\t\t2 群发消息");
                            System.out.println("\t\t3 私聊消息");
                            System.out.println("\t\t4 发送文件");
                            System.out.println("\t\t9 退出登录");
                            System.out.println("请输入你的选择");
                            key = Utility.readString(1);
                            switch(key){
                                case "1":
                                    System.out.println("拉取在线用户列表");
                                    userClientService.onlineFriendList();
                                    break;
                                case "2":
                                    System.out.print("请输入相对大家说的话：");
                                    String s = Utility.readString(100);
                                    //这里是一个方法, 将消息发送给所有在线用户
                                    messageClientService.sendMessageToAll(s, userID);
                                    break;
                                case "3":
                                    System.out.print("请输入想聊天的在线用户账号：");
                                    String getterId = Utility.readString(50);
                                    System.out.print("请输入你的消息:");
                                    String content = Utility.readString(100);
                                    //这里是一个方法，实现将消息发送到服务端
                                    messageClientService.sendMessageToOne(content,userID, getterId);
                                    System.out.println("私聊消息");
                                    break;
                                case "4":
                                    System.out.println("发送文件");
                                    break;
                                case "9":
                                    System.out.println("退出系统");
                                    //调用一个方法，给服务器发送一个退出程序的message
                                    userClientService.logout();
                                    loop = false;
                                    break;
                            }
                        }
                    }else{
                        System.out.println("登录失败，你的用户名或密码失败");
                    }
                    break;
                case "9":
                    System.out.println("退出系统");
                    //这里我们如果还开启了其余子线程，需要关闭子线程，这样整个程序才会退出
                    //否则会退出异常
                    //System.exit(0)正常退出
                    loop = false;
                    break;
            }
        }
    }
}
