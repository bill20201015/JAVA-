package com.sk.qqframe;

import com.sk.qqserver.service.QQServer;

/**
 * @author sk
 * @version 1.0
 *该类创建QQServer,启动后台服务
 */
public class QQFrame {
    public static void main(String[] args) {
        new QQServer();
    }
}
