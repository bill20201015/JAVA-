package com.sk.qqserver.service;

import java.util.HashMap;
import java.util.Iterator;

/**
 * @author sk
 * @version 1.0
 * 该类用于管理和客户端通信的线程
 */
public class ManagerClientThreads {
    private static HashMap<String, ServerConnectionClientThread> hm =
            new HashMap<>();

    //添加线程对象到hm集合中
    public static void addClientThread(String userID, ServerConnectionClientThread serverConnectionClientThread){
        hm.put(userID, serverConnectionClientThread);
    }

    //根据userID返回一个线程
    public static ServerConnectionClientThread getServerClientTread(String userID){
        return hm.get(userID);
    }

    public static HashMap<String, ServerConnectionClientThread> getHm() {
        return hm;
    }

    //从集合中移除某个线程对象
    public static void removeServerConnectionClientThread(String userID){
        hm.remove(userID);
    }

    //这里编写方法，可以返回在线用户列表
    public static String getOnlineUser(){
        //集合遍历， 遍历hashmap的key
        Iterator<String> iterator = hm.keySet().iterator();
        String onlineUserList = "";
        while(iterator.hasNext()){
            onlineUserList = onlineUserList + iterator.next().toString() + " ";
        }
        return onlineUserList;
    }
}
