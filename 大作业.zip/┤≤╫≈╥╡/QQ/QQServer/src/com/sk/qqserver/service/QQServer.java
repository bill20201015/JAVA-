package com.sk.qqserver.service;

import com.sk.qqcommon.Message;
import com.sk.qqcommon.MessageType;
import com.sk.qqcommon.User;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;

/**
 * @author sk
 * @version 1.0
 * 服务器，监听9999端口，等待客户端的链接并保持通信
 */
public class QQServer {
    private ServerSocket ss  = null;
    //创建一个集合，存放多个用户，如果是这些用户登录，如果是这些用户登录则就是合法的
    private static HashMap<String, User> validUser = new HashMap<>();

    static {//在静态代码块中，初始化validUsers
        validUser.put("100", new User("100", "123456"));
        validUser.put("200", new User("200", "123456"));
        validUser.put("300", new User("300", "123456"));
        validUser.put("至尊宝", new User("至尊宝", "123456"));
        validUser.put("紫霞仙子", new User("紫霞仙子", "123456"));
        validUser.put("牛魔王", new User("牛魔王", "123456"));

    }

    //验证用户是否有效的方法
    private boolean checkUser(String userID, String password){
        User user = validUser.get(userID);
        if(user == null){
            System.out.println("用户不存在");
            return false;
        }
        if(!user.getPassword().equals(password)){
            System.out.println("密码错误");
            return false;
        }
        return true;
    }
    public QQServer(){

        try {
            System.out.println("服务器在9999端口监听。。。。");
            ss = new ServerSocket(9999);
            while(true){
                Socket socket = ss.accept();
                //得到socket关联的对象的输入流
                ObjectInputStream ois =
                        new ObjectInputStream(socket.getInputStream());
                //等到socket关联对象输出流
                ObjectOutputStream oos =
                        new ObjectOutputStream(socket.getOutputStream());
                User o = (User)ois.readObject();
                //创建一个Message对象，准备回复客户端
                Message message = new Message();
                //验证,是否合法.原先应该是从数据库中验证是否有该用户的信息
                if(checkUser(o.getUserID(), o.getPassword())){
                    message.setMesType(MessageType.MESSAGE_LOGIN_SUCCEED);
                    //将message对象回复客户端
                    oos.writeObject(message);
                    //创建一个线程，和客户端保持通信，需要持有socket
                    ServerConnectionClientThread serverConnectionClientThread =
                            new ServerConnectionClientThread(socket, o.getUserID());
                    serverConnectionClientThread.start();
                    //把该线程对象放入到一个集合中
                    ManagerClientThreads.addClientThread(o.getUserID(), serverConnectionClientThread);
                }else{//登录失败
                    System.out.println("用户"+o.getUserID()+"登录失败");
                    message.setMesType(MessageType.MESSAGE_LOGIN_FAIL);
                    oos.writeObject(message);
                    //关闭socket
                    socket.close();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            //如果服务端退出了while，说明服务器端不在监听，需要管壁serverSocket
            try {
                ss.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
