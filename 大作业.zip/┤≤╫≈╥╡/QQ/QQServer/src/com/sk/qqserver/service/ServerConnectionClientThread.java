package com.sk.qqserver.service;

import com.sk.qqcommon.Message;
import com.sk.qqcommon.MessageType;

import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.HashMap;
import java.util.Iterator;

/**
 * @author sk
 * @version 1.0
 * 该类的一个对象和某个客户端保持通信
 */
public class ServerConnectionClientThread extends Thread{
    private Socket socket;
    private String userID;

    public ServerConnectionClientThread(Socket socket, String userID) {
        this.socket = socket;
        this.userID = userID;
    }

    public Socket getSocket() {
        return socket;
    }

    @Override
    public void run(){//这里线程处于run的状态，可以发送接收消息
        while(true){
            try {

                System.out.println("服务器和客户端保持通信，"+userID+"用户正在读取数据");
                ObjectInputStream ois =
                        new ObjectInputStream(socket.getInputStream());
                Message message= (Message) ois.readObject();
                //根据message类型做相应的业务处理
                if(message.getMesType().equals(MessageType.MESSAGE_GET_ONLINE_FRIEND)){
                    //客户端在线用户列表
                    /*
                    在线用户列表形式， 100 200 紫霞仙子
                     */
                    System.out.println(message.getSender()+"正在要在线用户列表");
                    String onlineUser = ManagerClientThreads.getOnlineUser();
                    //返回message
                    //构建一个message对象
                    Message message2 = new Message();
                    message2.setMesType(MessageType.MESSAGE_GET_ONLINE_FRIEND);
                    message2.setContent(onlineUser);
                    message2.setGetter(message.getSender());
                    //写入到数据通道，返回给客户端
                    ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
                    oos.writeObject(message2);
                }else if(message.getMesType().equals(MessageType.MESSAGE_CLINT_EXIT)){

                    System.out.println(message.getSender() + "要退出登录了");
                    //将客户端对应线程从集合中删除
                    ManagerClientThreads.removeServerConnectionClientThread(message.getSender());
                    socket.close();//管壁连接
                    break;
                }else if(message.getMesType().equals(MessageType.MESSAGE_COMM_MES)){

                    System.out.println("进行私聊业务选项");
                    //根据getterID，得到线程
                    ServerConnectionClientThread serverClientTread =
                            ManagerClientThreads.getServerClientTread(message.getGetter());
                    //得到对应socket的对象输出流，将message发给制定客户端
                    ObjectOutputStream oos =
                            new ObjectOutputStream(serverClientTread.getSocket().getOutputStream());
                    oos.writeObject(message);//出发如果客户不在线，可以保存到数据库中，可以实现离线留言
                }else if(message.getMesType().equals(MessageType.MESSAGE_TO_ALL_MES)){
                    //群发消息
                    System.out.println("群发消息业务");
                    //遍历所有的线程，把所有的socket得到,然后转发message即可
                    HashMap<String, ServerConnectionClientThread> hm = ManagerClientThreads.getHm();
                    Iterator<String> iterator = hm.keySet().iterator();
                    while (iterator.hasNext()){
                        //取出在线用户的ID
                        String onlineUserID = iterator.next().toString();
                        if(!onlineUserID.equals(message.getSender())){//排除群发消息的用户，即不用给自己发消息
                            ObjectOutputStream oos =
                                    new ObjectOutputStream(hm.get(onlineUserID).getSocket().getOutputStream());
                            oos.writeObject(message);
                        }
                    }
                }
                else{
                    System.out.println("其它类型业务暂时不处理");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }


}
