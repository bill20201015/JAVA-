/**
 * @author sk
 * @version 1.0
 */
public class demo {
    public static void main(String[] args) {
        Server serverDemo = new Server();
    }
}
